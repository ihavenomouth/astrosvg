// @ts-expect-error
export { default as Prism } from '../Prism.astro';
