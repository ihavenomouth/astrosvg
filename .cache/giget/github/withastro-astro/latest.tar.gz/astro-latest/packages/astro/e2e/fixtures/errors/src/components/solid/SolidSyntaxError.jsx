import { h } from 'solid-js/web'

export default function ReactSyntaxError() {
  return (<div></div></div>);
}
