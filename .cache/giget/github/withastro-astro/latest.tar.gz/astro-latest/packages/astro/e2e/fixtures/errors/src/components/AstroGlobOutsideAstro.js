export function globSomething(Astro) {
  return Astro.glob('./*.lua')
}
