import { h } from 'preact';

export default function({ id }) {
	return <div id={id}>Preact client:only component</div>
}
