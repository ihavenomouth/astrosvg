
document.querySelector('h1').textContent = 'before';
