import React from 'react';

export default function({ id }) {
	return <div id={id}>Framework client:only component</div>
}
