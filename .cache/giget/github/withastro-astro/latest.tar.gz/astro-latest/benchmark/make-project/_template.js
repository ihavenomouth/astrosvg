/**
 * Create a new project in the `projectDir` directory. Make sure to clean up the
 * previous artifacts here before generating files.
 * @param {URL} projectDir
 */
export async function run(projectDir) {}
